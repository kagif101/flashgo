<?php
// configurasi //


// user_name boleh kosong //
$user_name="";

//user_gaid wajib isi
$user_gaid= "b6789a5b-6d7d-4e72-9d46-30a2d9f1871c";
//user_token wajib di isi //
$user_token="AbyeJn1rRgmnHoFG";

//user_id wajib di isi //
$user_id="Facebook_382753318947110";

// invite_code wajib di isi //
$invite_code="F1kgaNjv9C";

// Bearer wajib di isi //
$Bearer="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJGYWNlYm9va18zODI3NTMzMTg5NDcxMTAiLCJleHAiOiIxNTUxNDU1ODMyOTM5In0.Zbxz1VwyyrY0GNc4DTiNTm5H6Uxl_1HejkQjv_rY2NU";



?>